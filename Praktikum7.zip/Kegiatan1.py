#Activity 1
d={'Segitiga':"L=0.5*a*t",
   'Persegi':"L=s**2",
   'PersegiPanjang':"L=p*l",
   'Lingkaran':"L=pi*r**2",
   'JajaranGenjang':"L=a*t"}

print('''
No | Nama Bangun     | Rumus Luas
---|-----------------|------------
1  | Segitiga        | ''',d['Segitiga'],'''
2  | Persegi         | ''',d['Persegi'],'''
3  | Persegi Panjang | ''',d['PersegiPanjang'],'''
4  | Lingkaran       | ''',d['Lingkaran'],'''
5  | Jajaran Genjang | ''',d['JajaranGenjang'])