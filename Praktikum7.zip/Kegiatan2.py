#Activity 2
password="Aqshal"
for a in range(3):
    b=input("Masukkan password: ")
    if b==password:
        print("Anda berhasil login")
        break
    else:
        print("Password anda salah")
        if a==2:
            print("Anda telah gagal memasukkan password sebanyak 3 kali. Login anda gagal")
